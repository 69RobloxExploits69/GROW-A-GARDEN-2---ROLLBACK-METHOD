-- ╔══════════════════════════════════════════════════════╗
-- ║         ROBLOX KEY + HWID LOADER                     ║
-- ║  Place this at the TOP of your script                ║
-- ╚══════════════════════════════════════════════════════╝

local API_URL = "https://YOUR-APP.up.railway.app" -- 🔁 Replace with your Railway URL
local YOUR_KEY = "SCR-XXXXXXXXXXXXXXXX"            -- 🔁 Replace with the buyer's key

-- ──────────────────────────────────────────────────────
-- Get a device fingerprint (executor HWID or fallback)
-- ──────────────────────────────────────────────────────
local function getHWID()
    -- Most script executors expose a global HWID function
    if syn and syn.request then
        return tostring(game:GetService("RbxAnalyticsService"):GetClientId())
            .. "-" .. tostring(game.PlaceId)
    end

    -- Fallback: use executor identity string if available
    local ok, id = pcall(function()
        return identifyexecutor and identifyexecutor() or "unknown"
    end)

    -- Last resort: combine multiple identifiers
    local player = game:GetService("Players").LocalPlayer
    return tostring(player.UserId)
        .. "-" .. tostring(game.PlaceId)
        .. "-" .. tostring(game.JobId):sub(1, 8)
end

-- ──────────────────────────────────────────────────────
-- Send verification request to your Railway API
-- ──────────────────────────────────────────────────────
local function verifyKey(key, hwid)
    local HttpService = game:GetService("HttpService")

    local body = HttpService:JSONEncode({ key = key, hwid = hwid })

    local ok, response = pcall(function()
        -- Use executor's HTTP function (bypasses Roblox HTTP restrictions)
        return (syn and syn.request or request or http_request)({
            Url    = API_URL .. "/verify",
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body   = body,
        })
    end)

    if not ok then
        return false, "HTTP request failed: " .. tostring(response)
    end

    local parsed = HttpService:JSONDecode(response.Body)
    return parsed.valid, parsed.reason or parsed.message or "Unknown"
end

-- ──────────────────────────────────────────────────────
-- Main auth check
-- ──────────────────────────────────────────────────────
local hwid   = getHWID()
local valid, reason = verifyKey(YOUR_KEY, hwid)

if not valid then
    -- Show error UI and kill execution
    local ScreenGui = Instance.new("ScreenGui")
    local Frame     = Instance.new("Frame", ScreenGui)
    local Label     = Instance.new("TextLabel", Frame)
    local SubLabel  = Instance.new("TextLabel", Frame)

    ScreenGui.Name            = "KeyError"
    ScreenGui.ResetOnSpawn    = false
    ScreenGui.ZIndexBehavior  = Enum.ZIndexBehavior.Sibling
    pcall(function() ScreenGui.Parent = game:GetService("CoreGui") end)

    Frame.Size                = UDim2.new(0, 420, 0, 110)
    Frame.Position            = UDim2.new(0.5, -210, 0.5, -55)
    Frame.BackgroundColor3    = Color3.fromRGB(18, 18, 18)
    Frame.BorderSizePixel     = 0
    Instance.new("UICorner", Frame).CornerRadius = UDim.new(0, 10)

    Label.Size                = UDim2.new(1, 0, 0.5, 0)
    Label.Position            = UDim2.new(0, 0, 0, 10)
    Label.BackgroundTransparency = 1
    Label.Text                = "❌  Key Invalid"
    Label.TextColor3          = Color3.fromRGB(255, 80, 80)
    Label.TextScaled          = true
    Label.Font                = Enum.Font.GothamBold

    SubLabel.Size             = UDim2.new(1, -20, 0.4, 0)
    SubLabel.Position         = UDim2.new(0, 10, 0.55, 0)
    SubLabel.BackgroundTransparency = 1
    SubLabel.Text             = "Reason: " .. tostring(reason)
    SubLabel.TextColor3       = Color3.fromRGB(180, 180, 180)
    SubLabel.TextScaled       = true
    SubLabel.Font             = Enum.Font.Gotham

    task.delay(5, function() ScreenGui:Destroy() end)

    -- Hard stop — nothing below this runs
    error("[KeySystem] Access denied: " .. tostring(reason))
end

-- ──────────────────────────────────────────────────────
-- ✅ KEY VALID — your script continues below this line
-- ──────────────────────────────────────────────────────
print("[KeySystem] Authorized ✅")

-- ════════════════════════════════════════════════════════
--   PUT YOUR ACTUAL SCRIPT CODE HERE ↓
-- ════════════════════════════════════════════════════════
