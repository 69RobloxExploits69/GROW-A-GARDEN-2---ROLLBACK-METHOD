require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const { v4: uuidv4 } = require('uuid');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(express.json());

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ─── Rate Limiting ────────────────────────────────────────────────────────────
const verifyLimiter = rateLimit({ windowMs: 60 * 1000, max: 20 });
const adminLimiter  = rateLimit({ windowMs: 60 * 1000, max: 10 });

// ─── Admin auth middleware ────────────────────────────────────────────────────
function adminAuth(req, res, next) {
  const secret = req.headers['x-admin-secret'];
  if (!secret || secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// ─────────────────────────────────────────────────────────────────────────────
//  PUBLIC: POST /verify
//  Called by the Roblox script on every load
//  Body: { key, hwid }
// ─────────────────────────────────────────────────────────────────────────────
app.post('/verify', verifyLimiter, async (req, res) => {
  const { key, hwid } = req.body;
  if (!key || !hwid) return res.status(400).json({ valid: false, reason: 'Missing key or hwid' });

  try {
    const result = await pool.query('SELECT * FROM keys WHERE key = $1', [key]);
    if (result.rows.length === 0) return res.json({ valid: false, reason: 'Invalid key' });

    const row = result.rows[0];

    if (!row.active)      return res.json({ valid: false, reason: 'Key is disabled' });
    if (row.expires_at && new Date() > new Date(row.expires_at))
      return res.json({ valid: false, reason: 'Key expired' });

    // First use — bind HWID
    if (!row.hwid) {
      await pool.query('UPDATE keys SET hwid = $1, uses = uses + 1 WHERE key = $2', [hwid, key]);
      return res.json({ valid: true, message: 'Key activated and HWID bound' });
    }

    // HWID mismatch
    if (row.hwid !== hwid) return res.json({ valid: false, reason: 'HWID mismatch — key locked to another device' });

    // All good
    await pool.query('UPDATE keys SET uses = uses + 1 WHERE key = $1', [key]);
    return res.json({ valid: true, message: 'OK' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ valid: false, reason: 'Server error' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN: POST /admin/generate
//  Body: { note, days }   (days = null → lifetime)
// ─────────────────────────────────────────────────────────────────────────────
app.post('/admin/generate', adminLimiter, adminAuth, async (req, res) => {
  const { note = '', days = null, amount = 1 } = req.body;
  const keys = [];

  for (let i = 0; i < Math.min(amount, 50); i++) {
    const key = 'SCR-' + uuidv4().toUpperCase().replace(/-/g, '').slice(0, 16);
    const expires_at = days ? new Date(Date.now() + days * 86400000) : null;
    await pool.query(
      'INSERT INTO keys (key, note, expires_at) VALUES ($1, $2, $3)',
      [key, note, expires_at]
    );
    keys.push({ key, expires_at });
  }

  res.json({ success: true, keys });
});

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN: POST /admin/revoke
//  Body: { key }
// ─────────────────────────────────────────────────────────────────────────────
app.post('/admin/revoke', adminLimiter, adminAuth, async (req, res) => {
  const { key } = req.body;
  await pool.query('UPDATE keys SET active = false WHERE key = $1', [key]);
  res.json({ success: true });
});

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN: POST /admin/reset-hwid
//  Body: { key }
// ─────────────────────────────────────────────────────────────────────────────
app.post('/admin/reset-hwid', adminLimiter, adminAuth, async (req, res) => {
  const { key } = req.body;
  await pool.query('UPDATE keys SET hwid = NULL WHERE key = $1', [key]);
  res.json({ success: true, message: 'HWID reset — user can re-bind on next load' });
});

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN: GET /admin/list
// ─────────────────────────────────────────────────────────────────────────────
app.get('/admin/list', adminLimiter, adminAuth, async (req, res) => {
  const result = await pool.query('SELECT * FROM keys ORDER BY created_at DESC');
  res.json({ keys: result.rows });
});

// ─────────────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Key server running on port ${PORT}`));
