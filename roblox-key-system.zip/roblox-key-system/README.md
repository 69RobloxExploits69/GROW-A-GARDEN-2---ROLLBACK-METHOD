# Roblox Key System — Full Setup Guide

## Files Overview
```
roblox-key-system/
├── src/
│   ├── index.js       ← Express API (deploy this to Railway)
│   └── migrate.js     ← Creates the database table
├── package.json
├── Procfile           ← Tells Railway how to start
├── .env.example       ← Copy this to .env for local testing
├── loader.lua         ← Paste this into your Roblox script
└── admin.html         ← Open in browser to manage keys
```

---

## STEP 1 — Push to GitHub
1. Create a new **private** GitHub repo
2. Upload all these files to it
3. (or use Git CLI):
```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/YOU/your-repo.git
git push -u origin main
```

---

## STEP 2 — Set up Railway

1. Go to https://railway.app and sign in
2. Click **New Project → Deploy from GitHub repo**
3. Select your repo
4. Click **Add Plugin → PostgreSQL** (this auto-sets `DATABASE_URL`)
5. Go to your service → **Variables** tab, add:
   ```
   ADMIN_SECRET = some_long_random_password_you_make_up
   ```
6. Railway will auto-deploy. Copy your public URL (looks like `https://xxx.up.railway.app`)

---

## STEP 3 — Run the database migration

Railway has a built-in shell. Go to your service → **Deploy** tab → **Railway Shell** and run:
```bash
node src/migrate.js
```
This creates the `keys` table. You only need to do this once.

---

## STEP 4 — Set up your Roblox loader

Open `loader.lua` and replace two lines at the top:
```lua
local API_URL = "https://YOUR-APP.up.railway.app"  -- your Railway URL
local YOUR_KEY = "SCR-XXXXXXXXXXXXXXXX"             -- the buyer's key
```
Paste the entire `loader.lua` at the very top of your script. Your actual script code goes at the bottom where it says `-- PUT YOUR ACTUAL SCRIPT CODE HERE`.

---

## STEP 5 — Use the Admin Dashboard

1. Open `admin.html` in any browser (just double-click the file)
2. Enter your Railway URL and your `ADMIN_SECRET`
3. Click **Connect**

### Generating a key for a buyer:
- Set **Amount** to 1
- Set **Days** (e.g. `30` for 30-day license, or leave blank for lifetime)
- Add a **Note** (e.g. their Discord username)
- Click **Generate** — copy the key and send to buyer

### If a buyer changes PC:
- Paste their key → click **Reset HWID**
- They can re-bind on next script run

### Revoking a key:
- Paste their key → click **Revoke Key**

---

## How the HWID lock works

1. Buyer runs your script for the first time
2. Script sends their key + device fingerprint to your API
3. API saves the fingerprint and binds it to their key
4. Next time they load, fingerprint must match — if they share the script with someone else, it won't work because the fingerprint won't match

---

## API Endpoints (for reference)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/verify` | None | Verifies key + HWID (called by Lua) |
| POST | `/admin/generate` | Secret | Generate keys |
| POST | `/admin/revoke` | Secret | Disable a key |
| POST | `/admin/reset-hwid` | Secret | Unbind device from key |
| GET  | `/admin/list` | Secret | List all keys |

Admin auth: send header `x-admin-secret: YOUR_ADMIN_SECRET`
